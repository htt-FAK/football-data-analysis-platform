"""Football-Data.co.uk 数据导入器 — 下载并解析 CSV 赛事数据"""

import io
import logging
import re

import pandas as pd
import requests

from app.crawlers.base import BaseCrawler

logger = logging.getLogger(__name__)


class FootballDataImporter(BaseCrawler):
    """football-data.co.uk CSV 数据导入

    提供历年联赛比赛结果的 CSV 下载与解析。
    """

    # 联赛代码映射（football-data.co.uk 约定的 league code）
    LEAGUE_CODE = {
        "E0": "EPL",      # 英超
        "E1": "EFL Championship",
        "SP1": "La Liga",
        "I1": "Serie A",
        "D1": "Bundesliga",
        "F1": "Ligue 1",
    }

    def __init__(self):
        super().__init__(source_code="football_data",
                         base_url="https://www.football-data.co.uk/")
        self.csv_base_path = "mmz4281"

    def crawl(self, target: str = "matches", league: str = "E0",
              season: str = "2526", **kwargs) -> list[dict]:
        """采集入口

        Args:
            target: 采集目标，仅支持 "matches"（下载 CSV）
            league: 联赛代码（如 "E0" 表示英超）
            season: 赛季（如 "2526" 表示 2025-2026 赛季）
        """
        if target == "matches":
            return self._download_matches(league, season, **kwargs)
        else:
            logger.warning("不支持的目标: %s", target)
            return []

    @staticmethod
    def _normalize_season(season: str) -> str:
        """标准化赛季参数，兼容 2526 / 2025-2026 / 2025/2026 等形式。"""
        season_text = str(season).strip()
        if re.fullmatch(r"\d{4}", season_text):
            return season_text

        parts = re.findall(r"\d{2,4}", season_text)
        if len(parts) >= 2:
            return f"{int(parts[0]) % 100:02d}{int(parts[1]) % 100:02d}"
        return season_text

    def _candidate_urls(self, league: str, season: str) -> list[str]:
        """兼容当前站点路径和旧版 mmz{season} 路径。"""
        normalized_season = self._normalize_season(season)
        return [
            f"{self.base_url}{self.csv_base_path}/{normalized_season}/{league}.csv",
            f"{self.base_url}mmz{normalized_season}/{league}.csv",
        ]

    def _download_matches(self, league: str, season: str, **kwargs) -> list[dict]:
        """下载并解析 CSV 赛事数据"""
        resp = None
        for url in self._candidate_urls(league, season):
            try:
                resp = self._fetch(url)
                logger.info("[%s] 使用 CSV 源: %s", self.source_code, url)
                break
            except requests.RequestException:
                logger.warning("[%s] CSV 源不可用，尝试下一个: %s", self.source_code, url)

        if resp is None:
            logger.error("[%s] 未找到可用的 CSV 源: league=%s season=%s",
                         self.source_code, league, season)
            return []

        results: list[dict] = []
        try:
            # 直接基于字节流解析，避免编码/BOM 猜测导致首列异常。
            df = pd.read_csv(io.BytesIO(resp.content))
            # TODO: 字段标准化与清洗（日期格式、空值处理、列名统一）
            results = df.to_dict(orient="records")
        except Exception as e:
            logger.error("[%s] CSV 解析失败: %s", self.source_code, e)
        return results


class FootballDataCrawler(FootballDataImporter):
    """兼容旧调用名的爬虫入口。

    说明：
    - 项目内其他数据源普遍使用 `XXXCrawler` 命名。
    - 为了兼容既有调用代码、临时测试脚本和部署验证命令，
      这里为 `FootballDataImporter` 提供一个零行为差异的别名类。
    - 实际逻辑仍完全复用 `FootballDataImporter`，不引入额外分支。
    """

    pass
